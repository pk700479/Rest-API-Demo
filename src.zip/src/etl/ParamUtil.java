package etl;

import java.io.*;
import java.util.*;

public class ParamUtil {
    public static Map<String, String> loadParams(String filename) throws IOException {
        Map<String, String> params = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue; // Skip comments and empty lines
            }
            
            if (line.contains("=")) {
                String[] parts = line.split("=", 2);
                if (parts.length == 2) {
                    params.put(parts[0].trim(), parts[1].trim());
                }
            }
        }
        reader.close();
        
        // Process REPORT_NAMES into individual entries
        if (params.containsKey("REPORT_NAMES")) {
            String[] reports = params.get("REPORT_NAMES").split(",");
            for (int i = 0; i < reports.length; i++) {
                params.put("COMMON_RPT_NAME" + (i+1), reports[i].trim());
            }
        }
        
        return params;
    }
}