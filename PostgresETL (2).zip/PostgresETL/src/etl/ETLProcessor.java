package etl;

import java.sql.*;
import java.util.*;

public class ETLProcessor {
    private final Map<String, String> params;
    private final Map<String, Integer> clientProcessCounts = new HashMap<>();

    public ETLProcessor(Map<String, String> params) {
        this.params = params;
        // Initialize client counters
        clientProcessCounts.put("02378", 0); // Arconic
        clientProcessCounts.put("16731", 0); // Howmet
    }

    public void runETL() throws SQLException {
        // Dynamically determine how many reports we have
        int reportCount = 0;
        while (params.containsKey("COMMON_RPT_NAME" + (reportCount + 1))) {
            reportCount++;
        }

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT user_id, dept_id FROM vpwh_alcoa")) {

            // Group departments by user
            Map<String, List<String>> userDepartments = new HashMap<>();
            while (rs.next()) {
                String userId = rs.getString("user_id");
                String deptId = rs.getString("dept_id");
                userDepartments.computeIfAbsent(userId, k -> new ArrayList<>())
                             .add(deptId.trim());
            }

            // Process each user
            for (Map.Entry<String, List<String>> entry : userDepartments.entrySet()) {
                String userId = entry.getKey();
                String clientId = userId.substring(0, 5);
                String clientPrefix = params.get("CLIENT_PREFIX_" + clientId);

                // Process all reports for this user
                for (int i = 1; i <= reportCount; i++) {
                    String commonName = params.get("COMMON_RPT_NAME" + i);
                    String fullReportName = clientPrefix + commonName;
                    processUserDepartments(conn, clientId, fullReportName, userId, entry.getValue());
                }

                // Update processing count
                if (clientProcessCounts.containsKey(clientId)) {
                    clientProcessCounts.put(clientId, clientProcessCounts.get(clientId) + 1);
                }
            }
        }

        // Print summary
        System.out.println("ETL process completed successfully.");
        clientProcessCounts.forEach((clientId, count) -> {
            String clientName = "02378".equals(clientId) ? "Arconic" : "Howmet";
            System.out.printf("%s Data processed successfully for %s (%d users)%n", 
                clientName, clientId, count);
        });
    }

    private void processUserDepartments(Connection conn, String clientId, String rptName, 
                                      String userId, List<String> departments) throws SQLException {
        String prefix = getReportPrefix(conn, rptName);
        StringBuilder pageScrtExpr = new StringBuilder();
        int exprCount = 0;

        // Sort departments in descending order
        departments.sort(Collections.reverseOrder());

        // Build combined expression with * wildcards
        for (String deptId : departments) {
            if (exprCount > 0) {
                pageScrtExpr.append(" OR ");
            }
            pageScrtExpr.append(prefix).append('"').append(deptId).append("*\"");
            exprCount++;
        }

        String pageScrtName = "P" + userId + "_" + rptName;
        int exprLength = pageScrtExpr.length();

        insertClientRecord(conn, clientId, userId, rptName, pageScrtName, 
                         pageScrtExpr.toString(), exprLength, exprCount);
    }

    private String getReportPrefix(Connection conn, String rptName) throws SQLException {
        final String sql = "SELECT rpt_index1 FROM vpwh_metadta_rpt_dfn WHERE rpt_name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, rptName);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("rpt_index1") + "-" : "L-";
            }
        }
    }

    private void insertClientRecord(Connection conn, String clientId, String userId, 
                                  String rptName, String pageScrtName, 
                                  String pageScrtExpr, int exprLength, int exprCount) throws SQLException {
        final String sql = "INSERT INTO vpwh_client_all " +
                         "(client_id, ee_id, rpt_name, page_scrt_name, " +
                         "page_scrt_expr, page_scrt_lngth, page_scrt_cnt) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, clientId);
            ps.setString(2, userId);
            ps.setString(3, rptName);
            ps.setString(4, pageScrtName);
            ps.setString(5, pageScrtExpr);
            ps.setInt(6, exprLength);
            ps.setInt(7, exprCount);
            ps.executeUpdate();
        }
    }
}