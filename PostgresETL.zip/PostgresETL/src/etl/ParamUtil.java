package etl;

import java.io.*;
import java.util.*;

public class ParamUtil {
    public static Map<String, String> loadParams(String filename) throws IOException {
        Map<String, String> params = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.contains("=")) {
                String[] parts = line.replace("$$", "").split("=");
                if (parts.length == 2) {
                    params.put(parts[0].trim(), parts[1].trim());
                }
            }
        }
        reader.close();
        return params;
    }
}