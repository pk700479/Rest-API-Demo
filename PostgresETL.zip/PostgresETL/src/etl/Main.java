package etl;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        try {
            Map<String, String> params = ParamUtil.loadParams("paramfile.txt");
            ETLProcessor etl = new ETLProcessor(params);
            etl.runETL();
            System.out.println("ETL process completed successfully.");
        } catch (Exception e) {
            System.err.println("ETL process failed:");
            e.printStackTrace();
        }
    }
}