package etl;

import java.sql.*;
import java.util.*;

public class ETLProcessor {
    private final Map<String, String> params;

    public ETLProcessor(Map<String, String> params) {
        this.params = params;
    }

    public void runETL() throws SQLException {
        String clientId = params.get("CLIENT_ID");
        // Get all report names from RPT_NAME1 to RPT_NAME4
        List<String> reportNames = Arrays.asList(
            params.get("RPT_NAME1"),
            params.get("RPT_NAME2"),
            params.get("RPT_NAME3"),
            params.get("RPT_NAME4")
        );

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT user_id, dept_id FROM vpwh_alcoa")) {

            // Group departments by user
            Map<String, List<String>> userDepartments = new HashMap<>();
            while (rs.next()) {
                String userId = rs.getString("user_id");
                String deptId = rs.getString("dept_id");
                userDepartments.computeIfAbsent(userId, k -> new ArrayList<>())
                              .add(deptId.trim());
            }

            // Process each user's departments for all report names
            for (Map.Entry<String, List<String>> entry : userDepartments.entrySet()) {
                for (String reportName : reportNames) {
                    processUserDepartments(conn, clientId, reportName, entry.getKey(), entry.getValue());
                }
            }
        }
    }

    private void processUserDepartments(Connection conn, String clientId, String rptName, 
                                      String userId, List<String> departments) throws SQLException {
        String prefix = getReportPrefix(conn, rptName);
        StringBuilder pageScrtExpr = new StringBuilder();
        int exprCount = 0;

        // Sort departments in descending order to match expected output
        departments.sort(Collections.reverseOrder());

        // Build combined expression with * wildcards
        for (String deptId : departments) {
            if (exprCount > 0) {
                pageScrtExpr.append(" OR ");
            }
            pageScrtExpr.append(prefix).append('"').append(deptId).append("*\"");
            exprCount++;
        }

        String pageScrtName = "P" + userId + "_" + rptName;
        int exprLength = pageScrtExpr.length();

        insertClientRecord(conn, clientId, userId, rptName, pageScrtName, 
                         pageScrtExpr.toString(), exprLength, exprCount);
    }

    private String getReportPrefix(Connection conn, String rptName) throws SQLException {
        final String sql = "SELECT rpt_index1 FROM vpwh_metadta_rpt_dfn WHERE rpt_name = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, rptName);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("rpt_index1") + "-" : "L-";
            }
        }
    }

    private void insertClientRecord(Connection conn, String clientId, String userId, 
                                  String rptName, String pageScrtName, 
                                  String pageScrtExpr, int exprLength, int exprCount) throws SQLException {
        final String sql = "INSERT INTO vpwh_client_all " +
                         "(client_id, ee_id, rpt_name, page_scrt_name, " +
                         "page_scrt_expr, page_scrt_lngth, page_scrt_cnt) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, clientId);
            ps.setString(2, userId);
            ps.setString(3, rptName);
            ps.setString(4, pageScrtName);
            ps.setString(5, pageScrtExpr);
            ps.setInt(6, exprLength);
            ps.setInt(7, exprCount);
            ps.executeUpdate();
        }
    }
}