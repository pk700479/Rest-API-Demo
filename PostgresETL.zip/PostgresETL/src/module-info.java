module PostgresETL {
    requires java.sql;
}