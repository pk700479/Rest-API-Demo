package readexcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadWriteExample {

    public static void main(String[] args) {
        String filePath = "C:\\Users\\user\\Desktop\\example.xlsx";

        // Check if file is accessible
        if (!isFileAccessible(filePath)) {
            System.err.println("Error: File is being used by another program or cannot be accessed");
            return;
        }

        // Read from Excel file
        List<Employee> employees = readExcelFile(filePath);

        System.out.println("\nData read from Excel:");
        employees.forEach(System.out::println);

        // Always append a new row
        employees.add(new Employee("New Client", "New Project", "New Department"));
        System.out.println("\nAppended a new row to the Excel data.");

        // Write back to Excel file with retry logic
        boolean writeSuccess = false;
        int retries = 3;

        while (!writeSuccess && retries > 0) {
            try {
                writeExcelFile(filePath, employees);
                writeSuccess = true;
                System.out.println("\nData successfully written to: " + filePath);
            } catch (IOException e) {
                retries--;
                System.err.println("Error writing file (" + retries + " retries left): " + e.getMessage());
                if (retries > 0) {
                    try {
                        Thread.sleep(1000); // Wait 1 second before retrying
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                }
            }
        }
    }

    private static boolean isFileAccessible(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            createNewExcelFile(filePath);
            return true;
        }

        File temp = new File(filePath + ".temp");
        boolean accessible = file.renameTo(temp);
        if (accessible) {
            temp.renameTo(file);
        }
        return accessible;
    }

    private static void createNewExcelFile(String filePath) {
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(filePath)) {

            Sheet sheet = workbook.createSheet("Employee Data");
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("clnt_name");
            headerRow.createCell(1).setCellValue("description");
            headerRow.createCell(2).setCellValue("department_name");

            workbook.write(fos);
            System.out.println("Created new Excel file at: " + filePath);
        } catch (IOException e) {
            System.err.println("Error creating new Excel file: " + e.getMessage());
        }
    }

    public static List<Employee> readExcelFile(String filePath) {
        List<Employee> employees = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String clientName = getCellValue(row.getCell(0));
                String description = getCellValue(row.getCell(1));
                String department = getCellValue(row.getCell(2));

                if (!clientName.isEmpty() || !description.isEmpty() || !department.isEmpty()) {
                    employees.add(new Employee(clientName, description, department));
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading Excel file: " + e.getMessage());
        }
        return employees;
    }

    public static void writeExcelFile(String filePath, List<Employee> employees) throws IOException {
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(filePath)) {

            Sheet sheet = workbook.createSheet("Employee Data");

            // Create header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("clnt_name");
            headerRow.createCell(1).setCellValue("description");
            headerRow.createCell(2).setCellValue("department_name");

            // Create data rows
            int rowNum = 1;
            for (Employee emp : employees) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(emp.getClientName());
                row.createCell(1).setCellValue(emp.getDescription());
                row.createCell(2).setCellValue(emp.getDepartment());
            }

            workbook.write(fos);
        }
    }

    private static String getCellValue(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return "";
        }
    }

    static class Employee {
        private String clientName;
        private String description;
        private String department;

        public Employee(String clientName, String description, String department) {
            this.clientName = clientName;
            this.description = description;
            this.department = department;
        }

        public String getClientName() {
            return clientName;
        }

        public String getDescription() {
            return description;
        }

        public String getDepartment() {
            return department;
        }

        @Override
        public String toString() {
            return String.format("%-20s | %-30s | %-15s",
                    clientName, description, department);
        }
    }
}
